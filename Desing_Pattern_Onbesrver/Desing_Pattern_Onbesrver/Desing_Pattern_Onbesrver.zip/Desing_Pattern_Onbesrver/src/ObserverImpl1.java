public class ObserverImpl1 implements Observer {

    @Override
    public void update(Observable observable) {

    }
}
